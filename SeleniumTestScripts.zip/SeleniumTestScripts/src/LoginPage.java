import org.testng.annotations.Test;

public class LoginPage extends Operations{
	
	
	@Test
	public void login() throws Exception {
	
		LoginPage();
		
		
	}
	
	
	
	

}
