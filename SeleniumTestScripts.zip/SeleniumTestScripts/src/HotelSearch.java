import org.testng.annotations.Test;

public class HotelSearch extends Operations {
	@Test
	
	public void hotel() throws Exception 
	    {
		HotelSearch();
		}

	}
