import org.testng.annotations.Test;


public class RegistrationPage extends Operations
	{
	LaunchBrowser l1=new LaunchBrowser();
	
	@Test
		public void abc() throws Exception {
	
		l1.browser();
		SignUpPage();
	
		}
	}
	
	
	
